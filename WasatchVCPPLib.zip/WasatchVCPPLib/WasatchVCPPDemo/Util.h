#pragma once

#include <string>

class Util
{
    static std::string timestamp();
};

