#pragma once
#include <map>
#include "WasatchVCPP.h"
class AFX_EXT_CLASS CTestLeakProject
{
public:
	CTestLeakProject() {}
	~CTestLeakProject();
	void ShowMsg();
	void OpenSpectroMeter();
	std::map<int,WasatchVCPP::Proxy::Spectrometer*> spectrometers; // example
};

