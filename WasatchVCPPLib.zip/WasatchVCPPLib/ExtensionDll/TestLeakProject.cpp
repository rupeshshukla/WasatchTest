#include "pch.h"
#include "TestLeakProject.h"
CTestLeakProject::~CTestLeakProject()
{
	if (spectrometers.size()>0)
	{
		std::map<int, WasatchVCPP::Proxy::Spectrometer*>::iterator it = spectrometers.find(0);
		if (it != spectrometers.end())
		{
			it->second->close();
			delete it->second;
		}
	}
}

void CTestLeakProject::OpenSpectroMeter()
{
	spectrometers.clear();

	auto enumeratedCount = wp_open_all_spectrometers();
	if (enumeratedCount <= 0)
		return ;
	int validCount = 0;
	for (int index = 0; index < enumeratedCount; index++)
	{
		auto pixels = wp_get_pixels(index);
		if (pixels > 0)
		{
			WasatchVCPP::Proxy::Spectrometer *spec = new WasatchVCPP::Proxy::Spectrometer(index);
			spectrometers.insert(std::make_pair(validCount, spec));
			validCount++;
		}
	}
}

void CTestLeakProject::ShowMsg()
{
	::AfxMessageBox(_T("here i am"));

}